﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalcFun
{
    public partial class CalcFunc : Form
    {
        public CalcFunc()
        {
            InitializeComponent();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            float VarInteiro = float.Parse(textVal1.Text);
            float Vardecimal = float.Parse(textVal2.Text);
            float resultado;

            resultado = VarInteiro + Vardecimal;
            MessageBox.Show("Soma: " + resultado);
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            float VarInteiro = float.Parse(textVal1.Text);
            float Vardecimal = float.Parse(textVal2.Text);
            float resultado;

            resultado = VarInteiro - Vardecimal;
            MessageBox.Show("SUBTRAÇÃO: " + resultado);


        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            float VarInteiro = float.Parse(textVal1.Text);
            float Vardecimal = float.Parse(textVal2.Text);
            float resultado;

            resultado = VarInteiro * Vardecimal;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            float VarInteiro = float.Parse(textVal1.Text);
            float Vardecimal = float.Parse(textVal2.Text);
            float resultado;

            resultado = VarInteiro / Vardecimal;
            MessageBox.Show("Divisão: " + resultado);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textVal1.Text = "";
            textVal2.Text = "";


        }

        private void CalcFunc_Load(object sender, EventArgs e)
        {

        }
    }
 }

