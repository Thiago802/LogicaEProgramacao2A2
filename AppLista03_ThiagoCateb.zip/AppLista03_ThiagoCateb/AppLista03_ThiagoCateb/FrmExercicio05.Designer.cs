﻿namespace AppLista03_ThiagoCateb
{
    partial class FrmExercicio05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.lblBase = new System.Windows.Forms.Label();
            this.lblArea = new System.Windows.Forms.Label();
            this.lblResArea = new System.Windows.Forms.Label();
            this.lblPerimetro = new System.Windows.Forms.Label();
            this.lblResPerimetro = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtAltura
            // 
            this.txtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAltura.Location = new System.Drawing.Point(52, 162);
            this.txtAltura.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(219, 26);
            this.txtAltura.TabIndex = 0;
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(47, 96);
            this.lblAltura.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(70, 24);
            this.lblAltura.TabIndex = 1;
            this.lblAltura.Text = "Altura:";
            // 
            // txtBase
            // 
            this.txtBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBase.Location = new System.Drawing.Point(53, 309);
            this.txtBase.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(219, 26);
            this.txtBase.TabIndex = 2;
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBase.Location = new System.Drawing.Point(47, 241);
            this.lblBase.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(62, 24);
            this.lblBase.TabIndex = 3;
            this.lblBase.Text = "Base:";
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArea.Location = new System.Drawing.Point(503, 363);
            this.lblArea.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(60, 24);
            this.lblArea.TabIndex = 4;
            this.lblArea.Text = "Área:";
            // 
            // lblResArea
            // 
            this.lblResArea.AutoSize = true;
            this.lblResArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResArea.Location = new System.Drawing.Point(633, 363);
            this.lblResArea.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblResArea.Name = "lblResArea";
            this.lblResArea.Size = new System.Drawing.Size(17, 24);
            this.lblResArea.TabIndex = 5;
            this.lblResArea.Text = "-";
            // 
            // lblPerimetro
            // 
            this.lblPerimetro.AutoSize = true;
            this.lblPerimetro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerimetro.Location = new System.Drawing.Point(503, 446);
            this.lblPerimetro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPerimetro.Name = "lblPerimetro";
            this.lblPerimetro.Size = new System.Drawing.Size(106, 24);
            this.lblPerimetro.TabIndex = 6;
            this.lblPerimetro.Text = "Perimetro:";
            // 
            // lblResPerimetro
            // 
            this.lblResPerimetro.AutoSize = true;
            this.lblResPerimetro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResPerimetro.Location = new System.Drawing.Point(690, 446);
            this.lblResPerimetro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblResPerimetro.Name = "lblResPerimetro";
            this.lblResPerimetro.Size = new System.Drawing.Size(17, 24);
            this.lblResPerimetro.TabIndex = 7;
            this.lblResPerimetro.Text = "-";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Olive;
            this.panel1.Location = new System.Drawing.Point(869, 40);
            this.panel1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(148, 259);
            this.panel1.TabIndex = 8;
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(69, 382);
            this.btncalc.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(110, 44);
            this.btncalc.TabIndex = 9;
            this.btncalc.Text = "CACLULAR";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // FrmExercicio05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1333, 623);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblResPerimetro);
            this.Controls.Add(this.lblPerimetro);
            this.Controls.Add(this.lblResArea);
            this.Controls.Add(this.lblArea);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.txtBase);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.txtAltura);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "FrmExercicio05";
            this.Text = "FrmExercicio05";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.Label lblResArea;
        private System.Windows.Forms.Label lblPerimetro;
        private System.Windows.Forms.Label lblResPerimetro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btncalc;
    }
}