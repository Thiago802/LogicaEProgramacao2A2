﻿namespace AppLista03_ThiagoCateb
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblLitros = new System.Windows.Forms.Label();
            this.lblgasolina = new System.Windows.Forms.Label();
            this.txtgasolina = new System.Windows.Forms.TextBox();
            this.txtLitros = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "EXERCICIO 02";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblLitros
            // 
            this.lblLitros.AutoSize = true;
            this.lblLitros.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLitros.Location = new System.Drawing.Point(113, 104);
            this.lblLitros.Name = "lblLitros";
            this.lblLitros.Size = new System.Drawing.Size(81, 25);
            this.lblLitros.TabIndex = 2;
            this.lblLitros.Text = "LITROS:";
            this.lblLitros.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblgasolina
            // 
            this.lblgasolina.AutoSize = true;
            this.lblgasolina.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgasolina.Location = new System.Drawing.Point(66, 219);
            this.lblgasolina.Name = "lblgasolina";
            this.lblgasolina.Size = new System.Drawing.Size(178, 25);
            this.lblgasolina.TabIndex = 3;
            this.lblgasolina.Text = "VALOR GASOLINA:";
            // 
            // txtgasolina
            // 
            this.txtgasolina.Location = new System.Drawing.Point(71, 273);
            this.txtgasolina.Name = "txtgasolina";
            this.txtgasolina.Size = new System.Drawing.Size(173, 20);
            this.txtgasolina.TabIndex = 4;
            // 
            // txtLitros
            // 
            this.txtLitros.Location = new System.Drawing.Point(71, 158);
            this.txtLitros.Name = "txtLitros";
            this.txtLitros.Size = new System.Drawing.Size(173, 20);
            this.txtLitros.TabIndex = 5;
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(93, 351);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(113, 54);
            this.btnCalc.TabIndex = 6;
            this.btnCalc.Text = "CALCULAR";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(242)))), ((int)(((byte)(12)))));
            this.panel1.Location = new System.Drawing.Point(270, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(531, 452);
            this.panel1.TabIndex = 7;
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtLitros);
            this.Controls.Add(this.txtgasolina);
            this.Controls.Add(this.lblgasolina);
            this.Controls.Add(this.lblLitros);
            this.Controls.Add(this.label1);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblLitros;
        private System.Windows.Forms.Label lblgasolina;
        private System.Windows.Forms.TextBox txtgasolina;
        private System.Windows.Forms.TextBox txtLitros;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Panel panel1;
    }
}